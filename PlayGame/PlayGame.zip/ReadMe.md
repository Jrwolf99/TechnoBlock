# Tekno Block - How To Play

Press the following buttons to control the game:

Left Arrow Key - move left
Right Arrow Key - move right
Up Arrow Key - rotate block
Spacebar - slam piece down

ESC - Quit Game
